~ahs3/bin/gpufree

